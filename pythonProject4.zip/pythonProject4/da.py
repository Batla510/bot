import telebot
from telebot import types
from PIL import Image
from fpdf import FPDF



TOKEN = '7165893261:AAGq05QVx7_MnBEIHVAShRUHwhLbgwPo7cY'
bot = telebot.TeleBot(TOKEN)

all_sessions = {}  # Словарь для хранения текста по каждой сессии

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message,'Отправте фото и припишите номер машины')


@bot.message_handler(content_types=['text','photo'])
def handle_photo(message):
    text = message.caption
    try:
        # Получаем информацию о фото
        file_info = bot.get_file(message.photo[-1].file_id)
        downloaded_file = bot.download_file(file_info.file_path)

        # Сохраняем фото на сервере
        with open("photo.jpg", 'wb') as new_file:
            new_file.write(downloaded_file)

        # Определяем текущую сессию по ID пользователя
        session_id = message.from_user.id
        if session_id not in all_sessions:
            all_sessions[session_id] = ""

    except Exception as e:
        bot.reply_to(message, f"Произошла ошибка: {e}")
    # session_id = message.from_user.id
    # all_sessions[session_id] += text + "\n\n"
    # markup = types.ReplyKeyboardMarkup(resize_keyboard=True,one_time_keyboard=True)
    # markup.row(types.KeyboardButton("Да"),telebot.types.KeyboardButton("Нет"))
    btn = types.InlineKeyboardButton('Да',callback_data='btn1')
    btn2 = types.InlineKeyboardButton('Нет', callback_data='btn2')
    btn_kb = types.InlineKeyboardMarkup().add(btn,btn2)
    bot.send_message(message.chat.id, f"Текст на номерах: {text},правильно?", reply_markup=btn_kb)


@bot.message_handler(commands=['generate_report'])
def generate_report(message):
    try:
        # Создаем и отправляем PDF файл для отчета текущей сессии
        session_id = message.from_user.id
        if session_id in all_sessions:
            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Arial", size=12)
            pdf.cell(200, 10, txt="Отчет по распознанному тексту на номерах (Сессия)", ln=1, align='C')
            pdf.multi_cell(0, 10, all_sessions[session_id])
            pdf.output(f"report_session_{session_id}.pdf")

            with open(f"report_session_{session_id}.pdf", 'rb') as report_file:
                bot.send_document(message.chat.id, report_file)
        else:
            bot.reply_to(message, "Нет данных для генерации отчета в текущей сессии.")

    except Exception as e:
        bot.reply_to(message, f"Произошла ошибка при генерации отчета: {e}")


@bot.message_handler(commands=['end_session'])
def end_session(message):
    session_id = message.from_user.id
    if session_id in all_sessions:
        del all_sessions[session_id]
        bot.reply_to(message, "Сессия завершена. Данные по текущей сессии удалены.")
    else:
        bot.reply_to(message, "Нет активной сессии для завершения.")


bot.polling()
